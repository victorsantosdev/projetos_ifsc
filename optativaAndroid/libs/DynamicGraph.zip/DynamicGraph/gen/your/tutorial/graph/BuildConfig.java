/** Automatically generated file. DO NOT MODIFY */
package your.tutorial.graph;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}