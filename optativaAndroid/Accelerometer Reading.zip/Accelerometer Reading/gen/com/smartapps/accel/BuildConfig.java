/** Automatically generated file. DO NOT MODIFY */
package com.smartapps.accel;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}